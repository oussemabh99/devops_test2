#!/bin/sh
          docker build -t test:v1 . && docker run  -v ./data/:/data/ --privileged=true  test:v1
 

 # -t pour le tag      
 # -v pour mounter le volume data 
 # j'ai effectuer des changement au docker file 
 # finalement ça na pas marché à cause de la configuration de tomcat9 
